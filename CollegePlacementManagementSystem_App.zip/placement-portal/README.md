# College Placement Management System (Spring Boot + MySQL/H2 + JSP)

## Quick Start in Any Cloud Environment (GitHub Codespaces, Gitpod, Replit, Local)
1. **Run immediately (uses pre-seeded H2 database so you can take screenshots right away):**
   ```bash
   mvn spring-boot:run
   ```
   Open `http://localhost:8080` in your browser.

2. **Run with MySQL (as specified in Assignment 1 & 2):**
   - Start MySQL on port `3306` (default user `root`, password `root`, or update `src/main/resources/application-mysql.properties`).
   - Run:
   ```bash
   mvn spring-boot:run -Dspring-boot.run.profiles=mysql
   ```

3. **Run JUnit Tests (for Section 19 testing screenshots):**
   ```bash
   mvn test
   ```
