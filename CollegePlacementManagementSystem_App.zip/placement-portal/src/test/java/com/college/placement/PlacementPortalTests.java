package com.college.placement;

import com.college.placement.exception.BusinessRuleException;
import com.college.placement.model.JobPosting;
import com.college.placement.model.Student;
import com.college.placement.repository.JobPostingRepository;
import com.college.placement.repository.StudentRepository;
import com.college.placement.service.PlacementService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class PlacementPortalTests {

    @Autowired
    private PlacementService placementService;

    @Autowired
    private JobPostingRepository jobPostingRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private MockMvc mockMvc;

    // Business Rule Test 1: Low CGPA & Backlogs rejection
    @Test
    void testLowCgpaAndBacklogEligibilityRejected() {
        Student karthik = placementService.getStudentById(5L); // CGPA 6.45, 2 backlogs
        JobPosting zohoJob = placementService.getJobById(1L); // Min CGPA 7.50, 0 backlogs
        assertThrows(BusinessRuleException.class, () -> placementService.validateEligibility(karthik, zohoJob));
    }

    // Business Rule Test 2: Already placed student blocked from applying
    @Test
    void testAlreadyPlacedStudentBlocked() {
        Student priya = placementService.getStudentById(2L); // PLACED
        JobPosting tcsJob = placementService.getJobById(2L);
        assertThrows(BusinessRuleException.class, () -> placementService.validateEligibility(priya, tcsJob));
    }

    // Business Rule Test 3: Branch restriction check
    @Test
    void testIneligibleBranchRejected() {
        Student ananya = placementService.getStudentById(4L); // ECE, CGPA 8.35
        JobPosting zohoJob = placementService.getJobById(1L); // CSE,IT only
        assertThrows(BusinessRuleException.class, () -> placementService.validateEligibility(ananya, zohoJob));
    }

    // Custom Query Test 1: Eligible jobs query
    @Test
    void testEligibleJobsCustomQuery() {
        List<JobPosting> eligible = jobPostingRepository.findEligibleJobsForStudent(8.95, 0, "CSE");
        assertFalse(eligible.isEmpty());
    }

    // Custom Query Test 2: Department placement aggregation query
    @Test
    void testDepartmentStatsCustomQuery() {
        List<Object[]> stats = studentRepository.getDepartmentPlacementStats();
        assertEquals(4, stats.size());
    }

    // Endpoint Test 1: Dashboard route
    @Test
    void testDashboardEndpoint() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(view().name("dashboard"));
    }

    // Endpoint Test 2: AJAX Eligible Jobs API
    @Test
    void testAjaxEligibleJobsEndpoint() throws Exception {
        mockMvc.perform(get("/api/eligible-jobs/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].companyName").exists());
    }

    // Endpoint Test 3: AJAX Live Eligibility Check API
    @Test
    void testAjaxCheckEligibilityEndpoint() throws Exception {
        mockMvc.perform(get("/api/check-eligibility")
                        .param("studentId", "5")
                        .param("jobId", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.eligible").value(false));
    }
}
