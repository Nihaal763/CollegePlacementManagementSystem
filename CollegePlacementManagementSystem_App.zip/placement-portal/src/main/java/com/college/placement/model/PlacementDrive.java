package com.college.placement.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "placement_drives")
public class PlacementDrive {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "drive_id")
    private Long driveId;

    @Column(name = "drive_date", nullable = false)
    private LocalDate driveDate;

    @Column(name = "venue", length = 120)
    private String venue;

    @Column(name = "mode", length = 30)
    private String mode;

    @Column(name = "coordinator_name", length = 100)
    private String coordinatorName;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;

    public Long getDriveId() { return driveId; }
    public void setDriveId(Long driveId) { this.driveId = driveId; }
    public LocalDate getDriveDate() { return driveDate; }
    public void setDriveDate(LocalDate driveDate) { this.driveDate = driveDate; }
    public String getVenue() { return venue; }
    public void setVenue(String venue) { this.venue = venue; }
    public String getMode() { return mode; }
    public void setMode(String mode) { this.mode = mode; }
    public String getCoordinatorName() { return coordinatorName; }
    public void setCoordinatorName(String coordinatorName) { this.coordinatorName = coordinatorName; }
    public Company getCompany() { return company; }
    public void setCompany(Company company) { this.company = company; }
}
