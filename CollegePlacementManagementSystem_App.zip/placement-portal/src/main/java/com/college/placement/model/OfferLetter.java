package com.college.placement.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "offer_letters")
public class OfferLetter {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "offer_id")
    private Long offerId;

    @Column(name = "offer_code", nullable = false, unique = true, length = 40)
    private String offerCode;

    @Column(name = "offered_ctc_lpa", nullable = false)
    private Double offeredCtcLpa;

    @Column(name = "joining_date")
    private LocalDate joiningDate;

    @Column(name = "offer_status", nullable = false, length = 20)
    private String offerStatus = "ISSUED";

    @Column(name = "issued_date", nullable = false)
    private LocalDate issuedDate = LocalDate.now();

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "application_id", nullable = false, unique = true)
    private JobApplication jobApplication;

    public Long getOfferId() { return offerId; }
    public void setOfferId(Long offerId) { this.offerId = offerId; }
    public String getOfferCode() { return offerCode; }
    public void setOfferCode(String offerCode) { this.offerCode = offerCode; }
    public Double getOfferedCtcLpa() { return offeredCtcLpa; }
    public void setOfferedCtcLpa(Double offeredCtcLpa) { this.offeredCtcLpa = offeredCtcLpa; }
    public LocalDate getJoiningDate() { return joiningDate; }
    public void setJoiningDate(LocalDate joiningDate) { this.joiningDate = joiningDate; }
    public String getOfferStatus() { return offerStatus; }
    public void setOfferStatus(String offerStatus) { this.offerStatus = offerStatus; }
    public LocalDate getIssuedDate() { return issuedDate; }
    public void setIssuedDate(LocalDate issuedDate) { this.issuedDate = issuedDate; }
    public JobApplication getJobApplication() { return jobApplication; }
    public void setJobApplication(JobApplication jobApplication) { this.jobApplication = jobApplication; }
}
