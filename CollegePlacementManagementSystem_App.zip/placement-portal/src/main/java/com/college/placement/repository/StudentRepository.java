package com.college.placement.repository;

import com.college.placement.model.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface StudentRepository extends JpaRepository<Student, Long> {

    Optional<Student> findByRollNumber(String rollNumber);

    // Custom Query 1: Search & Filter students with pagination
    @Query("SELECT s FROM Student s WHERE " +
           "(:keyword IS NULL OR LOWER(s.fullName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(s.rollNumber) LIKE LOWER(CONCAT('%', :keyword, '%'))) AND " +
           "(:deptCode IS NULL OR :deptCode = '' OR s.department.deptCode = :deptCode) AND " +
           "(:status IS NULL OR :status = '' OR s.placementStatus = :status)")
    Page<Student> searchStudents(@Param("keyword") String keyword,
                                 @Param("deptCode") String deptCode,
                                 @Param("status") String status,
                                 Pageable pageable);

    // Custom Query 2: Department-wise placement statistics report
    @Query("SELECT s.department.deptCode, s.department.deptName, COUNT(s), " +
           "SUM(CASE WHEN s.placementStatus = 'PLACED' THEN 1 ELSE 0 END), " +
           "ROUND(AVG(s.cgpa), 2) " +
           "FROM Student s GROUP BY s.department.deptCode, s.department.deptName")
    List<Object[]> getDepartmentPlacementStats();

    // Custom Query 3: Count placed students
    @Query("SELECT COUNT(s) FROM Student s WHERE s.placementStatus = 'PLACED'")
    long countPlacedStudents();
}
