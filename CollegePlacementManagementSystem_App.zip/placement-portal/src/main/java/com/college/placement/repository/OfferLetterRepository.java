package com.college.placement.repository;

import com.college.placement.model.OfferLetter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface OfferLetterRepository extends JpaRepository<OfferLetter, Long> {

    // Custom Query 10: Company-wise offers and average CTC report
    @Query("SELECT o.jobApplication.jobPosting.company.companyName, COUNT(o), ROUND(AVG(o.offeredCtcLpa), 2), MAX(o.offeredCtcLpa) " +
           "FROM OfferLetter o GROUP BY o.jobApplication.jobPosting.company.companyName")
    List<Object[]> getCompanyOfferSummary();
}
