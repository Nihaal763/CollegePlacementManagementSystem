package com.college.placement.controller;

import com.college.placement.service.PlacementService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    private final PlacementService placementService;

    public DashboardController(PlacementService placementService) {
        this.placementService = placementService;
    }

    @GetMapping("/")
    public String dashboard(Model model) {
        model.addAttribute("totalStudents", placementService.getTotalStudents());
        model.addAttribute("placedStudents", placementService.getPlacedStudentsCount());
        model.addAttribute("totalCompanies", placementService.getTotalCompanies());
        model.addAttribute("totalJobs", placementService.getTotalJobs());
        model.addAttribute("totalApplications", placementService.getTotalApplications());
        model.addAttribute("totalOffers", placementService.getTotalOffers());
        model.addAttribute("recentApplications", placementService.getAllApplications());
        model.addAttribute("upcomingDrives", placementService.getAllDrives());
        return "dashboard";
    }
}
