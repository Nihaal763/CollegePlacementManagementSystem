package com.college.placement.repository;

import com.college.placement.model.PlacementDrive;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlacementDriveRepository extends JpaRepository<PlacementDrive, Long> {
}
