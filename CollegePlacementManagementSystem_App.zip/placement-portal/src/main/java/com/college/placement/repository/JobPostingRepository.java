package com.college.placement.repository;

import com.college.placement.model.JobPosting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface JobPostingRepository extends JpaRepository<JobPosting, Long> {

    // Custom Query 5: Find all eligible open jobs for a given student's CGPA, backlogs, and branch
    @Query("SELECT j FROM JobPosting j WHERE j.status = 'OPEN' " +
           "AND j.minCgpa <= :cgpa " +
           "AND j.maxBacklogs >= :backlogs " +
           "AND j.eligibleBranches LIKE CONCAT('%', :branch, '%') " +
           "ORDER BY j.ctcLpa DESC")
    List<JobPosting> findEligibleJobsForStudent(@Param("cgpa") Double cgpa,
                                                @Param("backlogs") Integer backlogs,
                                                @Param("branch") String branch);

    // Custom Query 6: Top-N highest CTC job postings
    @Query("SELECT j FROM JobPosting j ORDER BY j.ctcLpa DESC")
    List<JobPosting> findAllOrderByCtcDesc();
}
