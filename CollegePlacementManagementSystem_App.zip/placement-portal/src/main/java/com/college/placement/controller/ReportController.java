package com.college.placement.controller;

import com.college.placement.service.PlacementService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/reports")
public class ReportController {

    private final PlacementService placementService;

    public ReportController(PlacementService placementService) {
        this.placementService = placementService;
    }

    @GetMapping("/departments")
    public String departmentReport(Model model) {
        model.addAttribute("deptStats", placementService.getDepartmentStats());
        return "report/departments";
    }

    @GetMapping("/companies")
    public String companyReport(Model model) {
        model.addAttribute("companyStats", placementService.getCompanyOfferSummary());
        return "report/companies";
    }

    @GetMapping("/pipeline")
    public String pipelineReport(Model model) {
        model.addAttribute("pipelineStats", placementService.getApplicationStatusBreakdown());
        model.addAttribute("topJobs", placementService.getAllJobs());
        return "report/pipeline";
    }
}
