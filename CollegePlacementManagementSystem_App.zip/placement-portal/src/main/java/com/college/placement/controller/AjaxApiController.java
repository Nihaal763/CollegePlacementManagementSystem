package com.college.placement.controller;

import com.college.placement.exception.BusinessRuleException;
import com.college.placement.model.JobPosting;
import com.college.placement.model.Student;
import com.college.placement.service.PlacementService;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api")
public class AjaxApiController {

    private final PlacementService placementService;

    public AjaxApiController(PlacementService placementService) {
        this.placementService = placementService;
    }

    // AJAX Feature 1: Dynamically fetch jobs a selected student is eligible for
    @GetMapping("/eligible-jobs/{studentId}")
    public List<Map<String, Object>> getEligibleJobs(@PathVariable Long studentId) {
        List<JobPosting> jobs = placementService.getEligibleJobsForStudent(studentId);
        List<Map<String, Object>> response = new ArrayList<>();
        for (JobPosting j : jobs) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("jobId", j.getJobId());
            item.put("jobTitle", j.getJobTitle());
            item.put("companyName", j.getCompany().getCompanyName());
            item.put("ctcLpa", j.getCtcLpa());
            item.put("minCgpa", j.getMinCgpa());
            item.put("maxBacklogs", j.getMaxBacklogs());
            item.put("eligibleBranches", j.getEligibleBranches());
            item.put("openPositions", j.getOpenPositions());
            response.add(item);
        }
        return response;
    }

    // AJAX Feature 2: Live pre-submission eligibility check for (studentId, jobId)
    @GetMapping("/check-eligibility")
    public Map<String, Object> checkEligibility(@RequestParam Long studentId, @RequestParam Long jobId) {
        Map<String, Object> res = new LinkedHashMap<>();
        try {
            Student s = placementService.getStudentById(studentId);
            JobPosting j = placementService.getJobById(jobId);
            placementService.validateEligibility(s, j);
            res.put("eligible", true);
            res.put("message", "Eligible! " + s.getFullName() + " (CGPA: " + s.getCgpa() + ") meets all criteria for " + j.getJobTitle() + ".");
        } catch (BusinessRuleException ex) {
            res.put("eligible", false);
            res.put("message", ex.getMessage());
        }
        return res;
    }
}
