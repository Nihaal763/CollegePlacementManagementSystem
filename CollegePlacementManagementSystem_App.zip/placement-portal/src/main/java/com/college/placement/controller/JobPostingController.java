package com.college.placement.controller;

import com.college.placement.model.JobPosting;
import com.college.placement.service.PlacementService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/jobs")
public class JobPostingController {

    private final PlacementService placementService;

    public JobPostingController(PlacementService placementService) {
        this.placementService = placementService;
    }

    @GetMapping
    public String listJobs(Model model) {
        model.addAttribute("jobs", placementService.getAllJobs());
        model.addAttribute("students", placementService.searchStudents("", "", "", org.springframework.data.domain.PageRequest.of(0, 100)).getContent());
        return "job/list";
    }

    @GetMapping("/new")
    public String createForm(Model model) {
        model.addAttribute("job", new JobPosting());
        model.addAttribute("companies", placementService.searchCompanies("", org.springframework.data.domain.PageRequest.of(0, 100)).getContent());
        return "job/form";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        model.addAttribute("job", placementService.getJobById(id));
        model.addAttribute("companies", placementService.searchCompanies("", org.springframework.data.domain.PageRequest.of(0, 100)).getContent());
        return "job/form";
    }

    @PostMapping("/save")
    public String saveJob(@Valid @ModelAttribute("job") JobPosting job,
                          BindingResult result,
                          @RequestParam("companyId") Long companyId,
                          Model model,
                          RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            model.addAttribute("companies", placementService.searchCompanies("", org.springframework.data.domain.PageRequest.of(0, 100)).getContent());
            return "job/form";
        }
        placementService.saveJobPosting(job, companyId);
        redirectAttributes.addFlashAttribute("successMsg", "Job posting saved successfully!");
        return "redirect:/jobs";
    }

    @GetMapping("/delete/{id}")
    public String deleteJob(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        placementService.deleteJobPosting(id);
        redirectAttributes.addFlashAttribute("successMsg", "Job posting deleted.");
        return "redirect:/jobs";
    }
}
