package com.college.placement.controller;

import com.college.placement.exception.BusinessRuleException;
import com.college.placement.service.PlacementService;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/applications")
public class ApplicationController {

    private final PlacementService placementService;

    public ApplicationController(PlacementService placementService) {
        this.placementService = placementService;
    }

    @GetMapping
    public String listApplications(Model model) {
        model.addAttribute("applications", placementService.getAllApplications());
        return "application/list";
    }

    @GetMapping("/apply")
    public String applyPage(Model model) {
        model.addAttribute("students", placementService.searchStudents("", "", "", PageRequest.of(0, 100)).getContent());
        model.addAttribute("jobs", placementService.getAllJobs());
        return "application/apply";
    }

    @PostMapping("/submit")
    public String submitApplication(@RequestParam Long studentId,
                                    @RequestParam Long jobId,
                                    @RequestParam(required = false) String remarks,
                                    RedirectAttributes redirectAttributes) {
        try {
            placementService.applyForJob(studentId, jobId, remarks);
            redirectAttributes.addFlashAttribute("successMsg", "Application submitted after passing all eligibility rules!");
            return "redirect:/applications";
        } catch (BusinessRuleException ex) {
            redirectAttributes.addFlashAttribute("errorMsg", "Eligibility Check Failed: " + ex.getMessage());
            return "redirect:/applications/apply";
        }
    }

    @GetMapping("/evaluate/{id}")
    public String evaluatePage(@PathVariable Long id, Model model) {
        model.addAttribute("applicationId", id);
        model.addAttribute("applications", placementService.getAllApplications());
        return "application/evaluate";
    }

    @PostMapping("/evaluate")
    public String submitEvaluation(@RequestParam Long applicationId,
                                   @RequestParam Integer roundNumber,
                                   @RequestParam String roundName,
                                   @RequestParam Double score,
                                   @RequestParam String resultStatus,
                                   @RequestParam(required = false) String feedback,
                                   @RequestParam(defaultValue = "false") boolean finalSelection,
                                   RedirectAttributes redirectAttributes) {
        try {
            placementService.recordInterviewRound(applicationId, roundNumber, roundName, score, resultStatus, feedback, finalSelection);
            redirectAttributes.addFlashAttribute("successMsg",
                    finalSelection && "CLEARED".equalsIgnoreCase(resultStatus)
                            ? "Round saved, student marked PLACED, vacancy decremented, and Offer Letter generated!"
                            : "Interview round result recorded successfully.");
            return "redirect:/applications";
        } catch (BusinessRuleException ex) {
            redirectAttributes.addFlashAttribute("errorMsg", ex.getMessage());
            return "redirect:/applications/evaluate/" + applicationId;
        }
    }

    @GetMapping("/offers")
    public String listOffers(Model model) {
        model.addAttribute("offers", placementService.getAllOffers());
        return "application/offers";
    }
}
