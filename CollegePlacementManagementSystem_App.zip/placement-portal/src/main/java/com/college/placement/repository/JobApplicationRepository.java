package com.college.placement.repository;

import com.college.placement.model.JobApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface JobApplicationRepository extends JpaRepository<JobApplication, Long> {

    boolean existsByStudentStudentIdAndJobPostingJobId(Long studentId, Long jobId);

    // Custom Query 7: Fetch applications with student & company details ordered by latest first
    @Query("SELECT a FROM JobApplication a JOIN FETCH a.student JOIN FETCH a.jobPosting j JOIN FETCH j.company ORDER BY a.applicationId DESC")
    List<JobApplication> findAllWithDetails();

    // Custom Query 8: Count applications by status
    @Query("SELECT a.currentStatus, COUNT(a) FROM JobApplication a GROUP BY a.currentStatus")
    List<Object[]> countApplicationsByStatus();

    // Custom Query 9: Filter applications by student ID
    @Query("SELECT a FROM JobApplication a WHERE a.student.studentId = :studentId ORDER BY a.appliedDate DESC")
    List<JobApplication> findByStudentId(@Param("studentId") Long studentId);
}
