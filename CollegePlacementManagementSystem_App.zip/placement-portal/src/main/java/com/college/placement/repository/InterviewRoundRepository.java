package com.college.placement.repository;

import com.college.placement.model.InterviewRound;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface InterviewRoundRepository extends JpaRepository<InterviewRound, Long> {
    List<InterviewRound> findByJobApplicationApplicationIdOrderByRoundNumberAsc(Long applicationId);
}
