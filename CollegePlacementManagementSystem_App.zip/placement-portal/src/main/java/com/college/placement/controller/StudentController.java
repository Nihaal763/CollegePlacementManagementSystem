package com.college.placement.controller;

import com.college.placement.model.Student;
import com.college.placement.service.PlacementService;
import jakarta.validation.Valid;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/students")
public class StudentController {

    private final PlacementService placementService;

    public StudentController(PlacementService placementService) {
        this.placementService = placementService;
    }

    @GetMapping
    public String listStudents(@RequestParam(defaultValue = "") String keyword,
                               @RequestParam(defaultValue = "") String deptCode,
                               @RequestParam(defaultValue = "") String status,
                               @RequestParam(defaultValue = "0") int page,
                               @RequestParam(defaultValue = "cgpa") String sortBy,
                               @RequestParam(defaultValue = "desc") String sortDir,
                               Model model) {
        Sort sort = sortDir.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        model.addAttribute("studentPage", placementService.searchStudents(keyword, deptCode, status, PageRequest.of(page, 6, sort)));
        model.addAttribute("departments", placementService.getAllDepartments());
        model.addAttribute("keyword", keyword);
        model.addAttribute("deptCode", deptCode);
        model.addAttribute("status", status);
        model.addAttribute("sortBy", sortBy);
        model.addAttribute("sortDir", sortDir);
        return "student/list";
    }

    @GetMapping("/new")
    public String createForm(Model model) {
        model.addAttribute("student", new Student());
        model.addAttribute("departments", placementService.getAllDepartments());
        model.addAttribute("allSkills", placementService.getAllSkills());
        return "student/form";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        model.addAttribute("student", placementService.getStudentById(id));
        model.addAttribute("departments", placementService.getAllDepartments());
        model.addAttribute("allSkills", placementService.getAllSkills());
        return "student/form";
    }

    @PostMapping("/save")
    public String saveStudent(@Valid @ModelAttribute("student") Student student,
                              BindingResult result,
                              @RequestParam("deptId") Long deptId,
                              Model model,
                              RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            model.addAttribute("departments", placementService.getAllDepartments());
            model.addAttribute("allSkills", placementService.getAllSkills());
            return "student/form";
        }
        placementService.saveStudent(student, deptId);
        redirectAttributes.addFlashAttribute("successMsg", "Student record saved successfully!");
        return "redirect:/students";
    }

    @GetMapping("/delete/{id}")
    public String deleteStudent(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        placementService.deleteStudent(id);
        redirectAttributes.addFlashAttribute("successMsg", "Student record deleted.");
        return "redirect:/students";
    }
}
