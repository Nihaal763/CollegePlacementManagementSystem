package com.college.placement.controller;

import com.college.placement.model.Company;
import com.college.placement.service.PlacementService;
import jakarta.validation.Valid;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/companies")
public class CompanyController {

    private final PlacementService placementService;

    public CompanyController(PlacementService placementService) {
        this.placementService = placementService;
    }

    @GetMapping
    public String listCompanies(@RequestParam(defaultValue = "") String keyword,
                                @RequestParam(defaultValue = "0") int page,
                                @RequestParam(defaultValue = "companyName") String sortBy,
                                @RequestParam(defaultValue = "asc") String sortDir,
                                Model model) {
        Sort sort = sortDir.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        model.addAttribute("companyPage", placementService.searchCompanies(keyword, PageRequest.of(page, 6, sort)));
        model.addAttribute("keyword", keyword);
        model.addAttribute("sortBy", sortBy);
        model.addAttribute("sortDir", sortDir);
        return "company/list";
    }

    @GetMapping("/new")
    public String createForm(Model model) {
        model.addAttribute("company", new Company());
        return "company/form";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        model.addAttribute("company", placementService.getCompanyById(id));
        return "company/form";
    }

    @PostMapping("/save")
    public String saveCompany(@Valid @ModelAttribute("company") Company company,
                              BindingResult result,
                              RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "company/form";
        }
        placementService.saveCompany(company);
        redirectAttributes.addFlashAttribute("successMsg", "Company profile saved successfully!");
        return "redirect:/companies";
    }

    @GetMapping("/delete/{id}")
    public String deleteCompany(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        placementService.deleteCompany(id);
        redirectAttributes.addFlashAttribute("successMsg", "Company removed.");
        return "redirect:/companies";
    }
}
