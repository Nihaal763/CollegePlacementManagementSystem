package com.college.placement.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
@Table(name = "job_postings")
public class JobPosting {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "job_id")
    private Long jobId;

    @NotBlank(message = "Job title is required")
    @Column(name = "job_title", nullable = false, length = 120)
    private String jobTitle;

    @Column(name = "job_type", length = 30)
    private String jobType = "FULL_TIME";

    @DecimalMin(value = "1.0", message = "CTC must be at least 1.0 LPA")
    @Column(name = "ctc_lpa", nullable = false)
    private Double ctcLpa;

    @DecimalMin(value = "0.0")
    @DecimalMax(value = "10.0")
    @Column(name = "min_cgpa", nullable = false)
    private Double minCgpa;

    @Min(value = 0)
    @Column(name = "max_backlogs", nullable = false)
    private Integer maxBacklogs = 0;

    @NotBlank(message = "Eligible branches are required (e.g., CSE,IT)")
    @Column(name = "eligible_branches", nullable = false, length = 100)
    private String eligibleBranches;

    @Min(value = 1, message = "Open positions must be at least 1")
    @Column(name = "open_positions", nullable = false)
    private Integer openPositions;

    @Column(name = "application_deadline")
    private LocalDate applicationDeadline;

    @Column(name = "status", length = 20)
    private String status = "OPEN";

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;

    public Long getJobId() { return jobId; }
    public void setJobId(Long jobId) { this.jobId = jobId; }
    public String getJobTitle() { return jobTitle; }
    public void setJobTitle(String jobTitle) { this.jobTitle = jobTitle; }
    public String getJobType() { return jobType; }
    public void setJobType(String jobType) { this.jobType = jobType; }
    public Double getCtcLpa() { return ctcLpa; }
    public void setCtcLpa(Double ctcLpa) { this.ctcLpa = ctcLpa; }
    public Double getMinCgpa() { return minCgpa; }
    public void setMinCgpa(Double minCgpa) { this.minCgpa = minCgpa; }
    public Integer getMaxBacklogs() { return maxBacklogs; }
    public void setMaxBacklogs(Integer maxBacklogs) { this.maxBacklogs = maxBacklogs; }
    public String getEligibleBranches() { return eligibleBranches; }
    public void setEligibleBranches(String eligibleBranches) { this.eligibleBranches = eligibleBranches; }
    public Integer getOpenPositions() { return openPositions; }
    public void setOpenPositions(Integer openPositions) { this.openPositions = openPositions; }
    public LocalDate getApplicationDeadline() { return applicationDeadline; }
    public void setApplicationDeadline(LocalDate applicationDeadline) { this.applicationDeadline = applicationDeadline; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Company getCompany() { return company; }
    public void setCompany(Company company) { this.company = company; }
}
