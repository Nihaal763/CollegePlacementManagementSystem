package com.college.placement.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "companies")
public class Company {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "company_id")
    private Long companyId;

    @NotBlank(message = "Company name is required")
    @Column(name = "company_name", nullable = false, unique = true, length = 120)
    private String companyName;

    @NotBlank(message = "Industry sector is required")
    @Column(name = "industry", length = 80)
    private String industry;

    @Column(name = "website", length = 150)
    private String website;

    @NotBlank(message = "HR contact name is required")
    @Column(name = "hr_name", length = 100)
    private String hrName;

    @Email(message = "Valid HR email is required")
    @Column(name = "hr_email", length = 120)
    private String hrEmail;

    @Column(name = "city", length = 60)
    private String city;

    @OneToMany(mappedBy = "company", cascade = CascadeType.ALL)
    private List<JobPosting> jobPostings = new ArrayList<>();

    public Long getCompanyId() { return companyId; }
    public void setCompanyId(Long companyId) { this.companyId = companyId; }
    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }
    public String getIndustry() { return industry; }
    public void setIndustry(String industry) { this.industry = industry; }
    public String getWebsite() { return website; }
    public void setWebsite(String website) { this.website = website; }
    public String getHrName() { return hrName; }
    public void setHrName(String hrName) { this.hrName = hrName; }
    public String getHrEmail() { return hrEmail; }
    public void setHrEmail(String hrEmail) { this.hrEmail = hrEmail; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public List<JobPosting> getJobPostings() { return jobPostings; }
    public void setJobPostings(List<JobPosting> jobPostings) { this.jobPostings = jobPostings; }
}
