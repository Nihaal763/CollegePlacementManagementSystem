package com.college.placement.repository;

import com.college.placement.model.Company;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CompanyRepository extends JpaRepository<Company, Long> {

    // Custom Query 4: Search companies by name or industry with pagination
    @Query("SELECT c FROM Company c WHERE " +
           "(:keyword IS NULL OR LOWER(c.companyName) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "OR LOWER(c.industry) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<Company> searchCompanies(@Param("keyword") String keyword, Pageable pageable);
}
