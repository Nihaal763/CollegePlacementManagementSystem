package com.college.placement.service;

import com.college.placement.exception.BusinessRuleException;
import com.college.placement.exception.ResourceNotFoundException;
import com.college.placement.model.*;
import com.college.placement.repository.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

@Service
public class PlacementService {

    private final StudentRepository studentRepository;
    private final DepartmentRepository departmentRepository;
    private final CompanyRepository companyRepository;
    private final JobPostingRepository jobPostingRepository;
    private final JobApplicationRepository jobApplicationRepository;
    private final InterviewRoundRepository interviewRoundRepository;
    private final OfferLetterRepository offerLetterRepository;
    private final PlacementDriveRepository placementDriveRepository;
    private final SkillRepository skillRepository;

    public PlacementService(StudentRepository studentRepository,
                            DepartmentRepository departmentRepository,
                            CompanyRepository companyRepository,
                            JobPostingRepository jobPostingRepository,
                            JobApplicationRepository jobApplicationRepository,
                            InterviewRoundRepository interviewRoundRepository,
                            OfferLetterRepository offerLetterRepository,
                            PlacementDriveRepository placementDriveRepository,
                            SkillRepository skillRepository) {
        this.studentRepository = studentRepository;
        this.departmentRepository = departmentRepository;
        this.companyRepository = companyRepository;
        this.jobPostingRepository = jobPostingRepository;
        this.jobApplicationRepository = jobApplicationRepository;
        this.interviewRoundRepository = interviewRoundRepository;
        this.offerLetterRepository = offerLetterRepository;
        this.placementDriveRepository = placementDriveRepository;
        this.skillRepository = skillRepository;
    }

    // --- Student CRUD ---
    public Page<Student> searchStudents(String keyword, String deptCode, String status, Pageable pageable) {
        return studentRepository.searchStudents(keyword, deptCode, status, pageable);
    }

    public Student getStudentById(Long id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with ID: " + id));
    }

    public Student saveStudent(Student student, Long deptId) {
        Department dept = departmentRepository.findById(deptId)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found"));
        student.setDepartment(dept);
        return studentRepository.save(student);
    }

    public void deleteStudent(Long id) {
        Student s = getStudentById(id);
        studentRepository.delete(s);
    }

    // --- Company CRUD ---
    public Page<Company> searchCompanies(String keyword, Pageable pageable) {
        return companyRepository.searchCompanies(keyword, pageable);
    }

    public Company getCompanyById(Long id) {
        return companyRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Company not found with ID: " + id));
    }

    public Company saveCompany(Company company) {
        return companyRepository.save(company);
    }

    public void deleteCompany(Long id) {
        Company c = getCompanyById(id);
        companyRepository.delete(c);
    }

    // --- Job Posting CRUD ---
    public List<JobPosting> getAllJobs() {
        return jobPostingRepository.findAllOrderByCtcDesc();
    }

    public JobPosting getJobById(Long id) {
        return jobPostingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Job Posting not found with ID: " + id));
    }

    public JobPosting saveJobPosting(JobPosting job, Long companyId) {
        Company company = getCompanyById(companyId);
        job.setCompany(company);
        return jobPostingRepository.save(job);
    }

    public void deleteJobPosting(Long id) {
        JobPosting job = getJobById(id);
        jobPostingRepository.delete(job);
    }

    // --- Eligibility Check Helper (Business Rules 1-5) ---
    public void validateEligibility(Student student, JobPosting job) {
        // Rule 1: Job must be OPEN and have open positions
        if (!"OPEN".equalsIgnoreCase(job.getStatus()) || job.getOpenPositions() <= 0) {
            throw new BusinessRuleException("This job posting is currently closed or has no remaining vacancies.");
        }
        // Rule 2: Already placed students cannot apply for lower/equal CTC drives (One-Student-One-Core-Offer policy)
        if ("PLACED".equalsIgnoreCase(student.getPlacementStatus())) {
            throw new BusinessRuleException("Student " + student.getFullName() + " is already PLACED and locked from further applications.");
        }
        // Rule 3: Duplicate application prevention
        if (jobApplicationRepository.existsByStudentStudentIdAndJobPostingJobId(student.getStudentId(), job.getJobId())) {
            throw new BusinessRuleException("Student has already applied to this job role.");
        }
        // Rule 4: Minimum CGPA requirement
        if (student.getCgpa() < job.getMinCgpa()) {
            throw new BusinessRuleException("CGPA " + student.getCgpa() + " is below required cutoff (" + job.getMinCgpa() + ").");
        }
        // Rule 5: Maximum active backlogs & Eligible branch check
        if (student.getActiveBacklogs() > job.getMaxBacklogs()) {
            throw new BusinessRuleException("Active backlogs (" + student.getActiveBacklogs() + ") exceed allowed limit (" + job.getMaxBacklogs() + ").");
        }
        List<String> branches = Arrays.asList(job.getEligibleBranches().toUpperCase().split(","));
        if (!branches.contains(student.getDepartment().getDeptCode().toUpperCase())) {
            throw new BusinessRuleException("Branch " + student.getDepartment().getDeptCode() + " is not eligible for this role.");
        }
    }

    public List<JobPosting> getEligibleJobsForStudent(Long studentId) {
        Student student = getStudentById(studentId);
        return jobPostingRepository.findEligibleJobsForStudent(
                student.getCgpa(),
                student.getActiveBacklogs(),
                student.getDepartment().getDeptCode()
        );
    }

    // --- TRANSACTIONAL WORKFLOW 1: Student Job Application with Eligibility Enforcement ---
    @Transactional
    public JobApplication applyForJob(Long studentId, Long jobId, String remarks) {
        Student student = getStudentById(studentId);
        JobPosting job = getJobById(jobId);

        validateEligibility(student, job);

        JobApplication application = new JobApplication();
        application.setStudent(student);
        application.setJobPosting(job);
        application.setAppliedDate(LocalDate.now());
        application.setCurrentStatus("APPLIED");
        application.setRemarks(remarks != null && !remarks.isBlank() ? remarks : "Submitted via Placement Portal");

        return jobApplicationRepository.save(application);
    }

    // --- TRANSACTIONAL WORKFLOW 2: Round Evaluation + Automatic Offer Issuance & Seat Decrement ---
    @Transactional
    public void recordInterviewRound(Long applicationId, Integer roundNumber, String roundName,
                                     Double score, String resultStatus, String feedback, boolean finalSelection) {
        JobApplication app = jobApplicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Application not found with ID: " + applicationId));

        if ("SELECTED".equalsIgnoreCase(app.getCurrentStatus()) || "REJECTED".equalsIgnoreCase(app.getCurrentStatus())) {
            throw new BusinessRuleException("Cannot add rounds to a closed application (" + app.getCurrentStatus() + ").");
        }

        InterviewRound round = new InterviewRound();
        round.setJobApplication(app);
        round.setRoundNumber(roundNumber);
        round.setRoundName(roundName);
        round.setScore(score);
        round.setResultStatus(resultStatus);
        round.setFeedback(feedback);
        interviewRoundRepository.save(round);

        if ("FAILED".equalsIgnoreCase(resultStatus)) {
            app.setCurrentStatus("REJECTED");
            app.setRemarks("Eliminated in Round " + roundNumber + " (" + roundName + ")");
            jobApplicationRepository.save(app);
        } else if (finalSelection && "CLEARED".equalsIgnoreCase(resultStatus)) {
            JobPosting job = app.getJobPosting();
            if (job.getOpenPositions() <= 0) {
                throw new BusinessRuleException("No open positions left for this job posting.");
            }
            // Step 1: Mark application SELECTED
            app.setCurrentStatus("SELECTED");
            app.setRemarks("Selected after Round " + roundNumber);
            jobApplicationRepository.save(app);

            // Step 2: Update Student status to PLACED
            Student student = app.getStudent();
            student.setPlacementStatus("PLACED");
            studentRepository.save(student);

            // Step 3: Decrement open positions and close job if 0
            job.setOpenPositions(job.getOpenPositions() - 1);
            if (job.getOpenPositions() == 0) {
                job.setStatus("CLOSED");
            }
            jobPostingRepository.save(job);

            // Step 4: Generate Offer Letter
            OfferLetter offer = new OfferLetter();
            offer.setJobApplication(app);
            offer.setOfferCode("OFF-2026-" + job.getCompany().getCompanyId() + "-" + app.getApplicationId());
            offer.setOfferedCtcLpa(job.getCtcLpa());
            offer.setIssuedDate(LocalDate.now());
            offer.setJoiningDate(LocalDate.now().plusMonths(6));
            offer.setOfferStatus("ISSUED");
            offerLetterRepository.save(offer);
        } else {
            app.setCurrentStatus("SHORTLISTED");
            app.setRemarks("Cleared Round " + roundNumber + " (" + roundName + ")");
            jobApplicationRepository.save(app);
        }
    }

    // --- Reporting & Dashboard Queries ---
    public List<Department> getAllDepartments() { return departmentRepository.findAll(); }
    public List<Skill> getAllSkills() { return skillRepository.findAll(); }
    public List<JobApplication> getAllApplications() { return jobApplicationRepository.findAllWithDetails(); }
    public List<OfferLetter> getAllOffers() { return offerLetterRepository.findAll(); }
    public List<PlacementDrive> getAllDrives() { return placementDriveRepository.findAll(); }
    public List<Object[]> getDepartmentStats() { return studentRepository.getDepartmentPlacementStats(); }
    public List<Object[]> getCompanyOfferSummary() { return offerLetterRepository.getCompanyOfferSummary(); }
    public List<Object[]> getApplicationStatusBreakdown() { return jobApplicationRepository.countApplicationsByStatus(); }
    public long getTotalStudents() { return studentRepository.count(); }
    public long getPlacedStudentsCount() { return studentRepository.countPlacedStudents(); }
    public long getTotalCompanies() { return companyRepository.count(); }
    public long getTotalJobs() { return jobPostingRepository.count(); }
    public long getTotalApplications() { return jobApplicationRepository.count(); }
    public long getTotalOffers() { return offerLetterRepository.count(); }
}
