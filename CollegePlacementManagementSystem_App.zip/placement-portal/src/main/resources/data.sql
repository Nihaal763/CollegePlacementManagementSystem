INSERT INTO departments (dept_id, dept_code, dept_name, hod_name) VALUES
(1, 'CSE', 'Computer Science and Engineering', 'Dr. R. K. Sharma'),
(2, 'IT', 'Information Technology', 'Dr. S. Meenakshi'),
(3, 'ECE', 'Electronics and Communication Engineering', 'Dr. V. Narayanan'),
(4, 'EEE', 'Electrical and Electronics Engineering', 'Dr. P. Subramanian');

INSERT INTO skills (skill_id, skill_name, category) VALUES
(1, 'Java & Spring Boot', 'Backend'),
(2, 'SQL & MySQL', 'Database'),
(3, 'React & JavaScript', 'Frontend'),
(4, 'Python & Data Science', 'Analytics'),
(5, 'Data Structures & Algorithms', 'Core CS');

INSERT INTO students (student_id, roll_number, full_name, email, phone, cgpa, active_backlogs, graduation_year, placement_status, dept_id) VALUES
(1, '21CS101', 'Aarav Sharma', 'aarav.sharma@college.edu.in', '9876543210', 8.95, 0, 2026, 'UNPLACED', 1),
(2, '21CS102', 'Priya Nair', 'priya.nair@college.edu.in', '9876543211', 9.20, 0, 2026, 'PLACED', 1),
(3, '21IT105', 'Rohan Verma', 'rohan.verma@college.edu.in', '9876543212', 7.80, 0, 2026, 'UNPLACED', 2),
(4, '21EC110', 'Ananya Reddy', 'ananya.reddy@college.edu.in', '9876543213', 8.35, 0, 2026, 'UNPLACED', 3),
(5, '21CS118', 'Karthik Iyer', 'karthik.iyer@college.edu.in', '9876543214', 6.45, 2, 2026, 'UNPLACED', 1),
(6, '21EE109', 'Sneha Kulkarni', 'sneha.kulkarni@college.edu.in', '9876543215', 8.10, 0, 2026, 'UNPLACED', 4);

INSERT INTO student_skills (student_id, skill_id) VALUES
(1, 1), (1, 2), (1, 5),
(2, 1), (2, 3), (2, 5),
(3, 2), (3, 3),
(4, 4), (4, 5),
(5, 2),
(6, 1), (6, 4);

INSERT INTO companies (company_id, company_name, industry, website, hr_name, hr_email, city) VALUES
(1, 'Infosys Limited', 'IT Services & Consulting', 'https://www.infosys.com', 'Meera Krishnan', 'campus@infosys.com', 'Bengaluru'),
(2, 'TCS Digital', 'Enterprise Software', 'https://www.tcs.com', 'Rajeshwari Menon', 'talent@tcs.com', 'Hyderabad'),
(3, 'Zoho Corporation', 'Product Engineering', 'https://www.zoho.com', 'Arjun Sundar', 'university@zoho.com', 'Chennai'),
(4, 'Accenture India', 'Technology Consulting', 'https://www.accenture.com', 'Neha Kapoor', 'india.campus@accenture.com', 'Pune');

INSERT INTO job_postings (job_id, job_title, job_type, ctc_lpa, min_cgpa, max_backlogs, eligible_branches, open_positions, application_deadline, status, company_id) VALUES
(1, 'Software Engineer - Full Stack', 'FULL_TIME', 8.50, 7.50, 0, 'CSE,IT', 12, '2026-12-20', 'OPEN', 3),
(2, 'Systems Engineer Specialist', 'FULL_TIME', 7.00, 7.00, 0, 'CSE,IT,ECE,EEE', 25, '2026-12-25', 'OPEN', 2),
(3, 'Associate Application Developer', 'FULL_TIME', 5.50, 6.50, 1, 'CSE,IT,ECE', 30, '2026-12-28', 'OPEN', 4),
(4, 'Graduate Engineer Trainee', 'FULL_TIME', 4.50, 6.00, 2, 'CSE,IT,ECE,EEE', 40, '2026-12-30', 'OPEN', 1);

INSERT INTO placement_drives (drive_id, drive_date, venue, mode, coordinator_name, company_id) VALUES
(1, '2026-11-22', 'Main Auditorium & CS Lab 1', 'ON_CAMPUS', 'Prof. M. Venkatesh', 3),
(2, '2026-11-28', 'Seminar Hall B', 'HYBRID', 'Prof. K. Anuradha', 2);

INSERT INTO job_applications (application_id, applied_date, current_status, remarks, student_id, job_id) VALUES
(1, '2026-11-10', 'SELECTED', 'Cleared all technical and HR rounds', 2, 1),
(2, '2026-11-11', 'SHORTLISTED', 'Cleared Aptitude & Coding test', 1, 1),
(3, '2026-11-12', 'APPLIED', 'Resume verified by T&P cell', 3, 2),
(4, '2026-11-12', 'APPLIED', 'Eligible for Digital profile', 4, 2);

INSERT INTO interview_rounds (round_id, round_number, round_name, score, max_score, result_status, feedback, application_id) VALUES
(1, 1, 'Online Coding Assessment', 88.0, 100.0, 'CLEARED', 'Strong problem solving in Java', 1),
(2, 2, 'Technical Interview', 92.0, 100.0, 'CLEARED', 'Solid DBMS and Spring MVC fundamentals', 1),
(3, 1, 'Online Coding Assessment', 81.0, 100.0, 'CLEARED', 'Good algorithmic accuracy', 2);

INSERT INTO offer_letters (offer_id, offer_code, offered_ctc_lpa, joining_date, offer_status, issued_date, application_id) VALUES
(1, 'OFF-2026-ZOHO-001', 8.50, '2027-07-01', 'ACCEPTED', '2026-11-14', 1);
