function loadEligibleJobs(studentId) {
    if (!studentId) {
        $('#eligibleJobsContainer').html('<div class="alert alert-secondary">Select a student above to filter eligible jobs via AJAX.</div>');
        return;
    }
    $.get('/api/eligible-jobs/' + studentId, function(data) {
        if (data.length === 0) {
            $('#eligibleJobsContainer').html('<div class="alert alert-warning">No eligible open jobs found for this student based on CGPA, backlogs, and branch rules.</div>');
            return;
        }
        let html = '<table class="table table-bordered table-hover mt-2"><thead class="table-light"><tr><th>Company</th><th>Role</th><th>CTC (LPA)</th><th>Min CGPA</th><th>Branches</th><th>Vacancies</th></tr></thead><tbody>';
        data.forEach(function(j) {
            html += '<tr><td><strong>' + j.companyName + '</strong></td><td>' + j.jobTitle + '</td><td>' + j.ctcLpa + ' LPA</td><td>' + j.minCgpa + '</td><td>' + j.eligibleBranches + '</td><td>' + j.openPositions + '</td></tr>';
        });
        html += '</tbody></table>';
        $('#eligibleJobsContainer').html(html);
    });
}

function checkLiveEligibility() {
    const studentId = $('#studentId').val();
    const jobId = $('#jobId').val();
    if (!studentId || !jobId) return;
    $.get('/api/check-eligibility', { studentId: studentId, jobId: jobId }, function(res) {
        const box = $('#eligibilityAlert');
        box.removeClass('d-none alert-success alert-danger');
        if (res.eligible) {
            box.addClass('alert-success').text(res.message);
            $('#submitAppBtn').prop('disabled', false);
        } else {
            box.addClass('alert-danger').text('Ineligible: ' + res.message);
            $('#submitAppBtn').prop('disabled', true);
        }
    });
}
