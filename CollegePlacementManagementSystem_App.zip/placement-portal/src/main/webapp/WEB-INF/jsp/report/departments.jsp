<%@ include file="../common/header.jsp" %>
<div class="table-card">
    <h4>Report 1: Department-Wise Placement Statistics</h4>
    <table class="table table-bordered mt-3">
        <thead class="table-light"><tr><th>Branch Code</th><th>Department Name</th><th>Total Students</th><th>Placed Students</th><th>Average CGPA</th></tr></thead>
        <tbody>
        <c:forEach var="row" items="${deptStats}">
            <tr>
                <td><strong>${row[0]}</strong></td>
                <td>${row[1]}</td>
                <td>${row[2]}</td>
                <td><span class="badge bg-success">${row[3]}</span></td>
                <td>${row[4]}</td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
<%@ include file="../common/footer.jsp" %>
