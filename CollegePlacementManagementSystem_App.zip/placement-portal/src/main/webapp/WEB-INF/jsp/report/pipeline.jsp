<%@ include file="../common/header.jsp" %>
<div class="row g-4">
    <div class="col-md-5">
        <div class="table-card">
            <h4>Report 3A: Application Stage Breakdown</h4>
            <table class="table table-bordered mt-3">
                <thead class="table-light"><tr><th>Status</th><th>Count</th></tr></thead>
                <tbody>
                <c:forEach var="row" items="${pipelineStats}">
                    <tr><td><strong>${row[0]}</strong></td><td>${row[1]}</td></tr>
                </c:forEach>
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-md-7">
        <div class="table-card">
            <h4>Report 3B: Top Paying Job Postings (Ranked by CTC)</h4>
            <table class="table table-bordered mt-3">
                <thead class="table-light"><tr><th>Company</th><th>Role</th><th>CTC (LPA)</th><th>Remaining Seats</th></tr></thead>
                <tbody>
                <c:forEach var="j" items="${topJobs}">
                    <tr><td>${j.company.companyName}</td><td>${j.jobTitle}</td><td><strong>${j.ctcLpa} LPA</strong></td><td>${j.openPositions}</td></tr>
                </c:forEach>
                </tbody>
            </table>
        </div>
    </div>
</div>
<%@ include file="../common/footer.jsp" %>
