<%@ include file="../common/header.jsp" %>
<div class="table-card">
    <h4>Report 2: Company-Wise Offers &amp; CTC Summary</h4>
    <table class="table table-bordered mt-3">
        <thead class="table-light"><tr><th>Company Name</th><th>Total Offers Issued</th><th>Average CTC (LPA)</th><th>Highest CTC (LPA)</th></tr></thead>
        <tbody>
        <c:forEach var="row" items="${companyStats}">
            <tr>
                <td><strong>${row[0]}</strong></td>
                <td>${row[1]}</td>
                <td>${row[2]} LPA</td>
                <td><span class="badge bg-primary">${row[3]} LPA</span></td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
<%@ include file="../common/footer.jsp" %>
