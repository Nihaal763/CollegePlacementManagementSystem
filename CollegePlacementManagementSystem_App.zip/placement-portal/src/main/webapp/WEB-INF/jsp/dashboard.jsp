<%@ include file="common/header.jsp" %>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Placement Cell Dashboard</h3>
    <div>
        <a href="${pageContext.request.contextPath}/applications/apply" class="btn btn-success me-2">+ New Job Application</a>
        <a href="${pageContext.request.contextPath}/students/new" class="btn btn-outline-primary">+ Register Student</a>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-2"><div class="card stat-card p-3 text-center"><small class="text-muted">Total Students</small><h3 class="text-primary mb-0">${totalStudents}</h3></div></div>
    <div class="col-md-2"><div class="card stat-card p-3 text-center"><small class="text-muted">Placed Students</small><h3 class="text-success mb-0">${placedStudents}</h3></div></div>
    <div class="col-md-2"><div class="card stat-card p-3 text-center"><small class="text-muted">Recruiters</small><h3 class="text-dark mb-0">${totalCompanies}</h3></div></div>
    <div class="col-md-2"><div class="card stat-card p-3 text-center"><small class="text-muted">Active Jobs</small><h3 class="text-info mb-0">${totalJobs}</h3></div></div>
    <div class="col-md-2"><div class="card stat-card p-3 text-center"><small class="text-muted">Applications</small><h3 class="text-warning mb-0">${totalApplications}</h3></div></div>
    <div class="col-md-2"><div class="card stat-card p-3 text-center"><small class="text-muted">Offers Issued</small><h3 class="text-danger mb-0">${totalOffers}</h3></div></div>
</div>

<div class="row g-4">
    <div class="col-md-8">
        <div class="table-card">
            <h5>Recent Student Applications</h5>
            <table class="table table-sm table-hover mt-3">
                <thead class="table-light"><tr><th>ID</th><th>Student</th><th>Company</th><th>Role</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                <c:forEach var="app" items="${recentApplications}">
                    <tr>
                        <td>#${app.applicationId}</td>
                        <td>${app.student.fullName} (${app.student.rollNumber})</td>
                        <td>${app.jobPosting.company.companyName}</td>
                        <td>${app.jobPosting.jobTitle}</td>
                        <td><span class="badge bg-${app.currentStatus == 'SELECTED' ? 'success' : (app.currentStatus == 'REJECTED' ? 'danger' : 'primary')}">${app.currentStatus}</span></td>
                        <td><a href="${pageContext.request.contextPath}/applications/evaluate/${app.applicationId}" class="btn btn-sm btn-outline-secondary">Evaluate</a></td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-md-4">
        <div class="table-card">
            <h5>Upcoming Campus Drives</h5>
            <ul class="list-group list-group-flush mt-3">
                <c:forEach var="d" items="${upcomingDrives}">
                    <li class="list-group-item">
                        <strong>${d.company.companyName}</strong> <span class="badge bg-info text-dark">${d.mode}</span><br>
                        <small class="text-muted">Date: ${d.driveDate} | Venue: ${d.venue}</small>
                    </li>
                </c:forEach>
            </ul>
        </div>
    </div>
</div>
<%@ include file="common/footer.jsp" %>
