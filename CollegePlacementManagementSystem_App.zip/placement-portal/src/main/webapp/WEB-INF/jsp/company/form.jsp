<%@ include file="../common/header.jsp" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<div class="table-card col-md-7 mx-auto">
    <h4>${company.companyId == null ? 'Add Recruiting Company' : 'Edit Company'}</h4>
    <form:form method="post" action="${pageContext.request.contextPath}/companies/save" modelAttribute="company">
        <form:hidden path="companyId"/>
        <div class="mb-3"><label class="form-label">Company Name *</label><form:input path="companyName" cssClass="form-control" required="required"/><form:errors path="companyName" cssClass="text-danger small"/></div>
        <div class="mb-3"><label class="form-label">Industry *</label><form:input path="industry" cssClass="form-control" required="required"/></div>
        <div class="mb-3"><label class="form-label">Headquarters City</label><form:input path="city" cssClass="form-control"/></div>
        <div class="mb-3"><label class="form-label">Website</label><form:input path="website" cssClass="form-control"/></div>
        <div class="mb-3"><label class="form-label">HR Name *</label><form:input path="hrName" cssClass="form-control" required="required"/></div>
        <div class="mb-3"><label class="form-label">HR Email *</label><form:input path="hrEmail" type="email" cssClass="form-control" required="required"/></div>
        <button type="submit" class="btn btn-primary">Save Company</button>
        <a href="${pageContext.request.contextPath}/companies" class="btn btn-secondary">Cancel</a>
    </form:form>
</div>
<%@ include file="../common/footer.jsp" %>
