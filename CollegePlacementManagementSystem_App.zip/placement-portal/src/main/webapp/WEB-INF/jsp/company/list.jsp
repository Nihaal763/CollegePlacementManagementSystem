<%@ include file="../common/header.jsp" %>
<div class="table-card">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Recruiting Companies</h4>
        <a href="${pageContext.request.contextPath}/companies/new" class="btn btn-primary">+ Add Company</a>
    </div>
    <form method="get" action="${pageContext.request.contextPath}/companies" class="row g-2 mb-3">
        <div class="col-md-6"><input type="text" name="keyword" value="${keyword}" class="form-control" placeholder="Search company or industry..."></div>
        <div class="col-md-2"><button type="submit" class="btn btn-dark w-100">Search</button></div>
    </form>
    <table class="table table-bordered table-hover">
        <thead class="table-light">
        <tr>
            <th><a href="?keyword=${keyword}&sortBy=companyName&sortDir=${sortDir == 'asc' ? 'desc' : 'asc'}">Company Name</a></th>
            <th>Industry</th>
            <th>City</th>
            <th>HR Contact</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <c:forEach var="c" items="${companyPage.content}">
            <tr>
                <td><strong>${c.companyName}</strong></td>
                <td>${c.industry}</td>
                <td>${c.city}</td>
                <td>${c.hrName} (${c.hrEmail})</td>
                <td>
                    <a href="${pageContext.request.contextPath}/companies/edit/${c.companyId}" class="btn btn-sm btn-warning">Edit</a>
                    <a href="${pageContext.request.contextPath}/companies/delete/${c.companyId}" class="btn btn-sm btn-danger" onclick="return confirm('Delete company?')">Delete</a>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
    <nav>
        <ul class="pagination">
            <c:forEach begin="0" end="${companyPage.totalPages > 0 ? companyPage.totalPages - 1 : 0}" var="i">
                <li class="page-item ${companyPage.number == i ? 'active' : ''}">
                    <a class="page-link" href="?page=${i}&keyword=${keyword}&sortBy=${sortBy}&sortDir=${sortDir}">${i + 1}</a>
                </li>
            </c:forEach>
        </ul>
    </nav>
</div>
<%@ include file="../common/footer.jsp" %>
