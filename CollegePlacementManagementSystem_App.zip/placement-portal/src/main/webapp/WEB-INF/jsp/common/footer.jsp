</div>
<footer class="footer text-center">
    <div class="container">
        <span>Training &amp; Placement Cell &bull; College Placement Management System (Spring Boot + MySQL/JPA + JSP)</span>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="${pageContext.request.contextPath}/resources/js/app.js"></script>
</body>
</html>
