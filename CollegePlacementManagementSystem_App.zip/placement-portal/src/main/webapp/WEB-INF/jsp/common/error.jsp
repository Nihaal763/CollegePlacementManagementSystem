<%@ include file="header.jsp" %>
<div class="card border-danger my-5">
    <div class="card-header bg-danger text-white"><h5>${errorTitle}</h5></div>
    <div class="card-body">
        <p class="lead">${errorMessage}</p>
        <a href="${pageContext.request.contextPath}/" class="btn btn-primary">Return to Dashboard</a>
    </div>
</div>
<%@ include file="footer.jsp" %>
