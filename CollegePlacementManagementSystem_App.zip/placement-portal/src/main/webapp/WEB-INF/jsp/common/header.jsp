<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>College Placement Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="${pageContext.request.contextPath}/resources/css/style.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand" href="${pageContext.request.contextPath}/">T&amp;P Placement Portal</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/students">Students</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/companies">Companies</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/jobs">Job Postings</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/applications">Applications</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/applications/offers">Offers</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Reports</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="${pageContext.request.contextPath}/reports/departments">Department Placement Stats</a></li>
                        <li><a class="dropdown-item" href="${pageContext.request.contextPath}/reports/companies">Company CTC Summary</a></li>
                        <li><a class="dropdown-item" href="${pageContext.request.contextPath}/reports/pipeline">Recruitment Pipeline</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="container">
    <c:if test="${not empty successMsg}">
        <div class="alert alert-success alert-dismissible fade show">${successMsg}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    </c:if>
    <c:if test="${not empty errorMsg}">
        <div class="alert alert-danger alert-dismissible fade show">${errorMsg}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    </c:if>
