<%@ include file="../common/header.jsp" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<div class="table-card col-md-8 mx-auto">
    <h4>${job.jobId == null ? 'Create Job Posting' : 'Edit Job Posting'}</h4>
    <form:form method="post" action="${pageContext.request.contextPath}/jobs/save" modelAttribute="job">
        <form:hidden path="jobId"/>
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Company *</label>
                <select name="companyId" class="form-select" required>
                    <c:forEach var="c" items="${companies}">
                        <option value="${c.companyId}" ${job.company != null && job.company.companyId == c.companyId ? 'selected' : ''}>${c.companyName}</option>
                    </c:forEach>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Job Title *</label>
                <form:input path="jobTitle" cssClass="form-control" required="required"/>
            </div>
            <div class="col-md-4">
                <label class="form-label">CTC (LPA) *</label>
                <form:input path="ctcLpa" type="number" step="0.1" min="1" cssClass="form-control" required="required"/>
            </div>
            <div class="col-md-4">
                <label class="form-label">Minimum CGPA *</label>
                <form:input path="minCgpa" type="number" step="0.01" min="0" max="10" cssClass="form-control" required="required"/>
            </div>
            <div class="col-md-4">
                <label class="form-label">Max Backlogs Allowed *</label>
                <form:input path="maxBacklogs" type="number" min="0" cssClass="form-control" required="required"/>
            </div>
            <div class="col-md-6">
                <label class="form-label">Eligible Branches (comma separated) *</label>
                <form:input path="eligibleBranches" placeholder="CSE,IT,ECE" cssClass="form-control" required="required"/>
            </div>
            <div class="col-md-3">
                <label class="form-label">Openings *</label>
                <form:input path="openPositions" type="number" min="1" cssClass="form-control" required="required"/>
            </div>
            <div class="col-md-3">
                <label class="form-label">Status</label>
                <form:select path="status" cssClass="form-select">
                    <form:option value="OPEN">OPEN</form:option>
                    <form:option value="CLOSED">CLOSED</form:option>
                </form:select>
            </div>
        </div>
        <div class="mt-4">
            <button type="submit" class="btn btn-primary">Save Job Posting</button>
            <a href="${pageContext.request.contextPath}/jobs" class="btn btn-secondary">Cancel</a>
        </div>
    </form:form>
</div>
<%@ include file="../common/footer.jsp" %>
