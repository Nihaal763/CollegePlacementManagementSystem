<%@ include file="../common/header.jsp" %>
<div class="table-card mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Active Job Postings</h4>
        <a href="${pageContext.request.contextPath}/jobs/new" class="btn btn-primary">+ Post New Job</a>
    </div>
    <table class="table table-bordered table-hover">
        <thead class="table-light"><tr><th>Company</th><th>Role</th><th>CTC (LPA)</th><th>Min CGPA</th><th>Max Backlogs</th><th>Branches</th><th>Openings</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
        <c:forEach var="j" items="${jobs}">
            <tr>
                <td><strong>${j.company.companyName}</strong></td>
                <td>${j.jobTitle}</td>
                <td>${j.ctcLpa} LPA</td>
                <td>${j.minCgpa}</td>
                <td>${j.maxBacklogs}</td>
                <td>${j.eligibleBranches}</td>
                <td>${j.openPositions}</td>
                <td><span class="badge bg-${j.status == 'OPEN' ? 'success' : 'secondary'}">${j.status}</span></td>
                <td>
                    <a href="${pageContext.request.contextPath}/jobs/edit/${j.jobId}" class="btn btn-sm btn-warning">Edit</a>
                    <a href="${pageContext.request.contextPath}/jobs/delete/${j.jobId}" class="btn btn-sm btn-danger" onclick="return confirm('Delete job posting?')">Delete</a>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>

<div class="table-card">
    <h5>AJAX Student Eligibility Filter</h5>
    <p class="text-muted small">Select any student to dynamically query matching jobs from the server without reloading the page.</p>
    <div class="col-md-5 mb-3">
        <select class="form-select" onchange="loadEligibleJobs(this.value)">
            <option value="">-- Choose Student --</option>
            <c:forEach var="s" items="${students}">
                <option value="${s.studentId}">${s.rollNumber} - ${s.fullName} (${s.department.deptCode}, CGPA: ${s.cgpa}, Backlogs: ${s.activeBacklogs})</option>
            </c:forEach>
        </select>
    </div>
    <div id="eligibleJobsContainer">
        <div class="alert alert-secondary">Select a student above to view eligible jobs.</div>
    </div>
</div>
<%@ include file="../common/footer.jsp" %>
