<%@ include file="../common/header.jsp" %>
<div class="table-card">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Student Directory</h4>
        <a href="${pageContext.request.contextPath}/students/new" class="btn btn-primary">+ Add Student</a>
    </div>
    <form method="get" action="${pageContext.request.contextPath}/students" class="row g-2 mb-3">
        <div class="col-md-4"><input type="text" name="keyword" value="${keyword}" class="form-control" placeholder="Search name or roll no..."></div>
        <div class="col-md-3">
            <select name="deptCode" class="form-select">
                <option value="">All Branches</option>
                <c:forEach var="d" items="${departments}">
                    <option value="${d.deptCode}" ${deptCode == d.deptCode ? 'selected' : ''}>${d.deptCode} - ${d.deptName}</option>
                </c:forEach>
            </select>
        </div>
        <div class="col-md-3">
            <select name="status" class="form-select">
                <option value="">All Statuses</option>
                <option value="UNPLACED" ${status == 'UNPLACED' ? 'selected' : ''}>UNPLACED</option>
                <option value="PLACED" ${status == 'PLACED' ? 'selected' : ''}>PLACED</option>
            </select>
        </div>
        <div class="col-md-2"><button type="submit" class="btn btn-dark w-100">Filter</button></div>
    </form>

    <table class="table table-bordered table-hover align-middle">
        <thead class="table-light">
        <tr>
            <th>Roll No</th>
            <th><a href="?keyword=${keyword}&deptCode=${deptCode}&status=${status}&sortBy=fullName&sortDir=${sortDir == 'asc' ? 'desc' : 'asc'}">Name</a></th>
            <th>Branch</th>
            <th><a href="?keyword=${keyword}&deptCode=${deptCode}&status=${status}&sortBy=cgpa&sortDir=${sortDir == 'asc' ? 'desc' : 'asc'}">CGPA</a></th>
            <th>Backlogs</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <c:forEach var="s" items="${studentPage.content}">
            <tr>
                <td><strong>${s.rollNumber}</strong></td>
                <td>${s.fullName}<br><small class="text-muted">${s.email}</small></td>
                <td>${s.department.deptCode}</td>
                <td>${s.cgpa}</td>
                <td>${s.activeBacklogs}</td>
                <td><span class="badge bg-${s.placementStatus == 'PLACED' ? 'success' : 'secondary'}">${s.placementStatus}</span></td>
                <td>
                    <a href="${pageContext.request.contextPath}/students/edit/${s.studentId}" class="btn btn-sm btn-warning">Edit</a>
                    <a href="${pageContext.request.contextPath}/students/delete/${s.studentId}" class="btn btn-sm btn-danger" onclick="return confirm('Delete this student?')">Delete</a>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>

    <nav>
        <ul class="pagination">
            <c:forEach begin="0" end="${studentPage.totalPages > 0 ? studentPage.totalPages - 1 : 0}" var="i">
                <li class="page-item ${studentPage.number == i ? 'active' : ''}">
                    <a class="page-link" href="?page=${i}&keyword=${keyword}&deptCode=${deptCode}&status=${status}&sortBy=${sortBy}&sortDir=${sortDir}">${i + 1}</a>
                </li>
            </c:forEach>
        </ul>
    </nav>
</div>
<%@ include file="../common/footer.jsp" %>
