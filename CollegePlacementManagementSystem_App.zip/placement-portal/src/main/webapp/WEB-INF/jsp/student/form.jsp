<%@ include file="../common/header.jsp" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<div class="table-card col-md-8 mx-auto">
    <h4>${student.studentId == null ? 'Register New Student' : 'Edit Student Profile'}</h4>
    <form:form method="post" action="${pageContext.request.contextPath}/students/save" modelAttribute="student" onsubmit="return validateStudentForm()">
        <form:hidden path="studentId"/>
        <div class="row g-3 mt-1">
            <div class="col-md-6">
                <label class="form-label">Roll Number *</label>
                <form:input path="rollNumber" id="rollNumber" cssClass="form-control" required="required"/>
                <form:errors path="rollNumber" cssClass="text-danger small"/>
            </div>
            <div class="col-md-6">
                <label class="form-label">Full Name *</label>
                <form:input path="fullName" id="fullName" cssClass="form-control" required="required"/>
                <form:errors path="fullName" cssClass="text-danger small"/>
            </div>
            <div class="col-md-6">
                <label class="form-label">College Email *</label>
                <form:input path="email" type="email" cssClass="form-control" required="required"/>
                <form:errors path="email" cssClass="text-danger small"/>
            </div>
            <div class="col-md-6">
                <label class="form-label">Phone</label>
                <form:input path="phone" cssClass="form-control"/>
            </div>
            <div class="col-md-4">
                <label class="form-label">Department *</label>
                <select name="deptId" class="form-select" required>
                    <c:forEach var="d" items="${departments}">
                        <option value="${d.deptId}" ${student.department != null && student.department.deptId == d.deptId ? 'selected' : ''}>${d.deptCode} - ${d.deptName}</option>
                    </c:forEach>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">CGPA (0 - 10) *</label>
                <form:input path="cgpa" id="cgpa" type="number" step="0.01" min="0" max="10" cssClass="form-control" required="required"/>
                <form:errors path="cgpa" cssClass="text-danger small"/>
            </div>
            <div class="col-md-4">
                <label class="form-label">Active Backlogs *</label>
                <form:input path="activeBacklogs" id="backlogs" type="number" min="0" cssClass="form-control" required="required"/>
            </div>
            <div class="col-md-6">
                <label class="form-label">Placement Status</label>
                <form:select path="placementStatus" cssClass="form-select">
                    <form:option value="UNPLACED">UNPLACED</form:option>
                    <form:option value="PLACED">PLACED</form:option>
                </form:select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Graduation Year</label>
                <form:input path="graduationYear" type="number" cssClass="form-control"/>
            </div>
        </div>
        <div class="mt-4">
            <button type="submit" class="btn btn-primary">Save Student</button>
            <a href="${pageContext.request.contextPath}/students" class="btn btn-secondary">Cancel</a>
        </div>
    </form:form>
</div>
<script>
function validateStudentForm() {
    const cgpa = parseFloat(document.getElementById('cgpa').value);
    if (isNaN(cgpa) || cgpa < 0 || cgpa > 10) {
        alert('Client Validation: CGPA must be between 0.0 and 10.0');
        return false;
    }
    return true;
}
</script>
<%@ include file="../common/footer.jsp" %>
