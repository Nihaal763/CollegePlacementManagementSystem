<%@ include file="../common/header.jsp" %>
<div class="table-card col-md-7 mx-auto">
    <h4>Record Interview Round Result (Transactional Workflow 2)</h4>
    <p class="text-muted small">Checking "Final Selection" atomically updates application status, marks student PLACED, decrements job openings, and issues an Offer Letter.</p>
    <form method="post" action="${pageContext.request.contextPath}/applications/evaluate">
        <div class="mb-3">
            <label class="form-label">Application ID *</label>
            <select name="applicationId" class="form-select" required>
                <c:forEach var="a" items="${applications}">
                    <option value="${a.applicationId}" ${a.applicationId == applicationId ? 'selected' : ''}>#${a.applicationId} - ${a.student.fullName} (${a.jobPosting.company.companyName} - ${a.jobPosting.jobTitle})</option>
                </c:forEach>
            </select>
        </div>
        <div class="row g-3 mb-3">
            <div class="col-md-4"><label class="form-label">Round Number *</label><input type="number" name="roundNumber" value="1" min="1" class="form-control" required></div>
            <div class="col-md-8"><label class="form-label">Round Name *</label><input type="text" name="roundName" placeholder="e.g., Technical Interview" class="form-control" required></div>
        </div>
        <div class="row g-3 mb-3">
            <div class="col-md-6"><label class="form-label">Score (out of 100) *</label><input type="number" step="0.5" min="0" max="100" name="score" value="85" class="form-control" required></div>
            <div class="col-md-6">
                <label class="form-label">Round Outcome *</label>
                <select name="resultStatus" class="form-select">
                    <option value="CLEARED">CLEARED</option>
                    <option value="FAILED">FAILED</option>
                </select>
            </div>
        </div>
        <div class="mb-3"><label class="form-label">Interviewer Feedback</label><input type="text" name="feedback" class="form-control" placeholder="e.g., Strong SQL and Java skills"></div>
        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" name="finalSelection" value="true" id="finalSel">
            <label class="form-check-label fw-bold text-success" for="finalSel">Final Selection (Generate Offer Letter &amp; Mark Student PLACED)</label>
        </div>
        <button type="submit" class="btn btn-primary">Save Round Result</button>
        <a href="${pageContext.request.contextPath}/applications" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<%@ include file="../common/footer.jsp" %>
