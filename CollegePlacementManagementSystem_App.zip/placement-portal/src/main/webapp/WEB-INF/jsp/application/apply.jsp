<%@ include file="../common/header.jsp" %>
<div class="table-card col-md-7 mx-auto">
    <h4>Submit Job Application (Workflow 1)</h4>
    <p class="text-muted small">Enforces CGPA, active backlog, branch, duplicate check, and placement lock rules.</p>
    <div id="eligibilityAlert" class="alert d-none"></div>
    <form method="post" action="${pageContext.request.contextPath}/applications/submit">
        <div class="mb-3">
            <label class="form-label">Select Student *</label>
            <select name="studentId" id="studentId" class="form-select" onchange="checkLiveEligibility()" required>
                <option value="">-- Select Student --</option>
                <c:forEach var="s" items="${students}">
                    <option value="${s.studentId}">${s.rollNumber} - ${s.fullName} [${s.department.deptCode}, CGPA: ${s.cgpa}, Backlogs: ${s.activeBacklogs}, ${s.placementStatus}]</option>
                </c:forEach>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Select Job Posting *</label>
            <select name="jobId" id="jobId" class="form-select" onchange="checkLiveEligibility()" required>
                <option value="">-- Select Job Role --</option>
                <c:forEach var="j" items="${jobs}">
                    <option value="${j.jobId}">${j.company.companyName} - ${j.jobTitle} (Min CGPA: ${j.minCgpa}, Branches: ${j.eligibleBranches}, CTC: ${j.ctcLpa} LPA)</option>
                </c:forEach>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Remarks / Cover Note</label>
            <input type="text" name="remarks" class="form-control" placeholder="Optional note for T&P coordinator">
        </div>
        <button type="submit" id="submitAppBtn" class="btn btn-success">Submit Application</button>
        <a href="${pageContext.request.contextPath}/applications" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<%@ include file="../common/footer.jsp" %>
