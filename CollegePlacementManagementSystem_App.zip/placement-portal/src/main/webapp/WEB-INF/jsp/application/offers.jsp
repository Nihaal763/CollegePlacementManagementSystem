<%@ include file="../common/header.jsp" %>
<div class="table-card">
    <h4>Issued Offer Letters</h4>
    <table class="table table-bordered table-hover mt-3">
        <thead class="table-light"><tr><th>Offer Code</th><th>Student</th><th>Roll No</th><th>Company</th><th>Role</th><th>CTC (LPA)</th><th>Issued Date</th><th>Joining Date</th><th>Status</th></tr></thead>
        <tbody>
        <c:forEach var="o" items="${offers}">
            <tr>
                <td><strong>${o.offerCode}</strong></td>
                <td>${o.jobApplication.student.fullName}</td>
                <td>${o.jobApplication.student.rollNumber}</td>
                <td>${o.jobApplication.jobPosting.company.companyName}</td>
                <td>${o.jobApplication.jobPosting.jobTitle}</td>
                <td><span class="badge bg-success">${o.offeredCtcLpa} LPA</span></td>
                <td>${o.issuedDate}</td>
                <td>${o.joiningDate}</td>
                <td>${o.offerStatus}</td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
<%@ include file="../common/footer.jsp" %>
