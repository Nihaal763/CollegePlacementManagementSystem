<%@ include file="../common/header.jsp" %>
<div class="table-card">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Job Applications &amp; Selection Pipeline</h4>
        <a href="${pageContext.request.contextPath}/applications/apply" class="btn btn-success">+ Apply Student to Job</a>
    </div>
    <table class="table table-bordered table-hover align-middle">
        <thead class="table-light"><tr><th>App ID</th><th>Student</th><th>Branch / CGPA</th><th>Company &amp; Role</th><th>Applied Date</th><th>Status</th><th>Remarks</th><th>Action</th></tr></thead>
        <tbody>
        <c:forEach var="a" items="${applications}">
            <tr>
                <td>#${a.applicationId}</td>
                <td><strong>${a.student.fullName}</strong> (${a.student.rollNumber})</td>
                <td>${a.student.department.deptCode} | ${a.student.cgpa}</td>
                <td>${a.jobPosting.company.companyName} - ${a.jobPosting.jobTitle} (${a.jobPosting.ctcLpa} LPA)</td>
                <td>${a.appliedDate}</td>
                <td><span class="badge bg-${a.currentStatus == 'SELECTED' ? 'success' : (a.currentStatus == 'REJECTED' ? 'danger' : 'warning text-dark')}">${a.currentStatus}</span></td>
                <td>${a.remarks}</td>
                <td>
                    <c:if test="${a.currentStatus != 'SELECTED' && a.currentStatus != 'REJECTED'}">
                        <a href="${pageContext.request.contextPath}/applications/evaluate/${a.applicationId}" class="btn btn-sm btn-primary">Enter Round Result</a>
                    </c:if>
                    <c:if test="${a.currentStatus == 'SELECTED'}">
                        <a href="${pageContext.request.contextPath}/applications/offers" class="btn btn-sm btn-outline-success">View Offer</a>
                    </c:if>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
<%@ include file="../common/footer.jsp" %>
